from datetime import date
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool
from app.database import Base
from app import models
from app.services.reconciliation import run_reconciliation

def test_exact_invoice_match():
    engine=create_engine("sqlite://",connect_args={"check_same_thread":False},poolclass=StaticPool)
    Base.metadata.create_all(engine)
    db=sessionmaker(bind=engine)()
    company=models.Company(name="Demo Co");db.add(company);db.commit();db.refresh(company)
    a=models.ImportBatch(company_id=company.id,source="gstr2b",filename="2b.csv")
    b=models.ImportBatch(company_id=company.id,source="purchase_register",filename="purchase.csv")
    db.add_all([a,b]);db.commit()
    db.add_all([
      models.Invoice(company_id=company.id,import_batch_id=a.id,source="gstr2b",supplier_gstin="22AAAAA0000A1Z5",invoice_number="INV-001",invoice_date=date(2026,4,1),taxable_value=1000,igst=180,cgst=0,sgst=0,cess=0),
      models.Invoice(company_id=company.id,import_batch_id=b.id,source="purchase_register",supplier_gstin="22AAAAA0000A1Z5",invoice_number="INV001",invoice_date=date(2026,4,1),taxable_value=1000,igst=180,cgst=0,sgst=0,cess=0)
    ]);db.commit()
    run=run_reconciliation(db,company.id)
    assert run.matched_count==1
    assert run.review_count==0
    assert run.mismatch_count==0
