import csv, io, json, zipfile
from datetime import datetime, date
from pathlib import Path
from openpyxl import load_workbook

ALIASES = {
    "supplier_gstin": ["supplier_gstin", "gstin", "gstin of supplier", "ctin"],
    "invoice_number": ["invoice_number", "invoice no", "invoice number", "inum", "document number"],
    "invoice_date": ["invoice_date", "invoice date", "date", "idt", "document date"],
    "taxable_value": ["taxable_value", "taxable value", "taxable amount", "txval"],
    "igst": ["igst", "integrated tax", "iamt"],
    "cgst": ["cgst", "central tax", "camt"],
    "sgst": ["sgst", "state/ut tax", "state tax", "samt"],
    "cess": ["cess", "cess amount", "csamt"],
    "invoice_value": ["invoice_value", "invoice value", "total invoice value", "total amount"],
}
def _key(v): return str(v or "").strip().lower().replace("_", " ")

def _normalize(row):
    src={_key(k):v for k,v in row.items() if k is not None}
    out={}
    for target, aliases in ALIASES.items():
        for alias in aliases:
            if _key(alias) in src and src[_key(alias)] not in (None,""):
                out[target]=src[_key(alias)]; break
    return out

def _date(v):
    if v in (None,""): return None
    if isinstance(v,datetime): return v.date()
    if isinstance(v,date): return v
    s=str(v).strip()
    for fmt in ("%Y-%m-%d","%d-%m-%Y","%d/%m/%Y","%Y/%m/%d","%d-%b-%Y"):
        try: return datetime.strptime(s[:10],fmt).date()
        except ValueError: pass
    try: return datetime.fromisoformat(s.replace("Z","+00:00")).date()
    except ValueError: return None

def _num(v):
    try: return round(float(str(v).replace(",","").replace("₹","").strip()),2) if v not in (None,"") else 0.0
    except (TypeError,ValueError): return 0.0

def _csv(data):
    text=data.decode("utf-8-sig",errors="replace")
    try: dialect=csv.Sniffer().sniff(text[:2048])
    except csv.Error: dialect=csv.excel
    return list(csv.DictReader(io.StringIO(text),dialect=dialect))

def _xlsx(data):
    wb=load_workbook(io.BytesIO(data),read_only=True,data_only=True)
    ws=wb.active; it=ws.iter_rows(values_only=True)
    headers=[str(x).strip() if x is not None else "" for x in next(it,[])]
    return [dict(zip(headers,row)) for row in it if any(v is not None for v in row)]

def _json(data):
    obj=json.loads(data.decode("utf-8-sig"))
    if isinstance(obj,list): return obj
    if isinstance(obj,dict):
        for k in ("invoices","data","b2b","docdata","items","records"):
            if isinstance(obj.get(k),list): return obj[k]
        found=[]
        def walk(n):
            if isinstance(n,dict):
                if any(k in n for k in ("inum","invoice_number","Invoice Number")): found.append(n)
                else:
                    for v in n.values(): walk(v)
            elif isinstance(n,list):
                for v in n: walk(v)
        walk(obj)
        if found: return found
    raise ValueError("JSON structure not recognized; expected an invoice array or supported collection.")

def read_invoice_file(filename,data):
    suffix=Path(filename).suffix.lower()
    if suffix==".zip":
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            candidates=[n for n in z.namelist() if Path(n).suffix.lower() in (".csv",".json",".xlsx") and not n.startswith("__MACOSX/")]
            if not candidates: raise ValueError("ZIP contains no CSV, JSON or XLSX file.")
            inner=candidates[0]
            return read_invoice_file(inner,z.read(inner))
    if suffix==".csv": rows=_csv(data)
    elif suffix==".xlsx": rows=_xlsx(data)
    elif suffix==".json": rows=_json(data)
    else: raise ValueError("Unsupported file type. Use CSV, XLSX, JSON or ZIP.")
    good=[]; rejected=[]
    for ix,row in enumerate(rows,start=2):
        item=_normalize(row)
        number=str(item.get("invoice_number") or "").strip()
        if not number:
            rejected.append({"row":ix,"reason":"Missing invoice number"}); continue
        good.append({
            "supplier_gstin":str(item.get("supplier_gstin") or "").strip().upper() or None,
            "invoice_number":number,"invoice_date":_date(item.get("invoice_date")),
            "taxable_value":_num(item.get("taxable_value")),"igst":_num(item.get("igst")),
            "cgst":_num(item.get("cgst")),"sgst":_num(item.get("sgst")),"cess":_num(item.get("cess")),
            "invoice_value":_num(item.get("invoice_value")) if item.get("invoice_value") not in (None,"") else None,
            "raw_data":json.dumps(row,default=str,ensure_ascii=False)
        })
    return good,rejected,len(rows)
