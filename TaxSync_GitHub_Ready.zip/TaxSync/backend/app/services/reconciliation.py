from difflib import SequenceMatcher
from sqlalchemy.orm import Session
from ..models import Invoice, ReconciliationRun, MatchResult

def norm_invoice(value):
    return "".join(c for c in (value or "").upper() if c.isalnum())

def _tax(i): return round((i.igst or 0)+(i.cgst or 0)+(i.sgst or 0)+(i.cess or 0),2)
def _gap(a,b): return abs((a or 0)-(b or 0))
def _date_gap(a,b): return abs((a-b).days) if a and b else 999

def _within(a,b,amount_tol,pct_tol):
    gap=_gap(a,b); base=max(abs(a or 0),abs(b or 0),1)
    return gap<=amount_tol or gap/base*100<=pct_tol

def run_reconciliation(db:Session,company_id:int,tolerance_amount=1.0,tolerance_percent=0.5,date_tolerance_days=5):
    gstr=db.query(Invoice).filter_by(company_id=company_id,source="gstr2b").all()
    purchases=db.query(Invoice).filter_by(company_id=company_id,source="purchase_register").all()
    run=ReconciliationRun(company_id=company_id,tolerance_amount=tolerance_amount,tolerance_percent=tolerance_percent,
                          total_gstr2b=len(gstr),total_purchase=len(purchases))
    db.add(run); db.flush()
    used_p=set(); used_g=set(); results=[]
    index={}
    for p in purchases:
        index.setdefault(((p.supplier_gstin or "").upper(),norm_invoice(p.invoice_number)),[]).append(p)
    for g in gstr:
        key=((g.supplier_gstin or "").upper(),norm_invoice(g.invoice_number))
        candidates=[p for p in index.get(key,[]) if p.id not in used_p]
        if not candidates: continue
        p=min(candidates,key=lambda x:_gap(x.taxable_value,g.taxable_value))
        used_p.add(p.id); used_g.add(g.id)
        td=round(_gap(g.taxable_value,p.taxable_value),2); taxd=round(_gap(_tax(g),_tax(p)),2)
        dg=_date_gap(g.invoice_date,p.invoice_date)
        ok=_within(g.taxable_value,p.taxable_value,tolerance_amount,tolerance_percent) and _within(_tax(g),_tax(p),tolerance_amount,tolerance_percent) and dg<=date_tolerance_days
        if ok:
            status,cat,confidence="matched","exact_match",1.0
            explanation="Supplier GSTIN and normalized invoice number match; values and date are within configured tolerances."
            run.matched_count+=1
        else:
            status,cat,confidence="mismatch","amount_or_date_difference",1.0
            explanation=f"Invoice identity matches but needs investigation. Taxable difference ₹{td:.2f}; tax difference ₹{taxd:.2f}; date gap {dg} day(s)."
            run.mismatch_count+=1
        results.append(MatchResult(run_id=run.id,gstr2b_invoice_id=g.id,purchase_invoice_id=p.id,status=status,
            category=cat,confidence=confidence,explanation=explanation,taxable_difference=td,tax_difference=taxd))
    remaining_g=[g for g in gstr if g.id not in used_g]
    remaining_p=[p for p in purchases if p.id not in used_p]
    for g in remaining_g:
        best=None; best_score=0.0
        for p in remaining_p:
            sim=SequenceMatcher(None,norm_invoice(g.invoice_number),norm_invoice(p.invoice_number)).ratio()
            gst=1.0 if g.supplier_gstin and g.supplier_gstin==p.supplier_gstin else 0.0
            dg=_date_gap(g.invoice_date,p.invoice_date)
            date_score=max(0.0,1.0-dg/max(date_tolerance_days+1,1)) if dg!=999 else 0.0
            amount_score=1.0 if _within(g.taxable_value,p.taxable_value,tolerance_amount,tolerance_percent) else max(0.0,1.0-_gap(g.taxable_value,p.taxable_value)/max(abs(g.taxable_value),1))
            score=.50*sim+.25*gst+.15*date_score+.10*amount_score
            if score>best_score: best_score,best=score,p
        if best and best_score>=.72:
            remaining_p.remove(best); used_g.add(g.id); used_p.add(best.id)
            results.append(MatchResult(run_id=run.id,gstr2b_invoice_id=g.id,purchase_invoice_id=best.id,
                status="needs_review",category="possible_match",confidence=round(best_score,3),
                explanation=f"Possible match suggested ({best_score:.0%} confidence). Verify GSTIN, invoice number, date and values.",
                taxable_difference=round(_gap(g.taxable_value,best.taxable_value),2),
                tax_difference=round(_gap(_tax(g),_tax(best)),2)))
            run.review_count+=1
        else:
            results.append(MatchResult(run_id=run.id,gstr2b_invoice_id=g.id,purchase_invoice_id=None,status="mismatch",
                category="missing_in_purchase_register",confidence=1.0,
                explanation="GSTR-2B invoice has no sufficiently similar purchase-register entry. Verify period and source data."))
            run.mismatch_count+=1
    for p in remaining_p:
        results.append(MatchResult(run_id=run.id,gstr2b_invoice_id=None,purchase_invoice_id=p.id,status="mismatch",
            category="missing_in_gstr2b",confidence=1.0,
            explanation="Purchase-register invoice was not found in the imported GSTR-2B records."))
        run.mismatch_count+=1
    db.add_all(results); db.commit(); db.refresh(run)
    return run
