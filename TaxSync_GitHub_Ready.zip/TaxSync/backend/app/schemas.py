from datetime import datetime
from pydantic import BaseModel, Field, ConfigDict

class CompanyCreate(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    legal_name: str | None = None
    pan: str | None = Field(default=None, max_length=10)
    financial_year_start_month: int = Field(default=4, ge=1, le=12)
    gstins: list[str] = []

class CompanyOut(BaseModel):
    id: int
    name: str
    legal_name: str | None
    pan: str | None
    financial_year_start_month: int
    created_at: datetime
    model_config = ConfigDict(from_attributes=True)

class ReconcileRequest(BaseModel):
    tolerance_amount: float = Field(default=1.0, ge=0)
    tolerance_percent: float = Field(default=0.5, ge=0, le=100)
    date_tolerance_days: int = Field(default=5, ge=0, le=60)

class ReconciliationOut(BaseModel):
    id: int
    company_id: int
    total_gstr2b: int
    total_purchase: int
    matched_count: int
    review_count: int
    mismatch_count: int
    status: str
    created_at: datetime
    model_config = ConfigDict(from_attributes=True)
