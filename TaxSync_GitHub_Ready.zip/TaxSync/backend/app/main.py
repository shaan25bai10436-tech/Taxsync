from datetime import datetime
from pathlib import Path
from fastapi import FastAPI, Depends, HTTPException, UploadFile, File, Query
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from sqlalchemy import desc
from .config import settings
from .database import Base, engine, get_db
from . import models
from .schemas import CompanyCreate, CompanyOut, ReconcileRequest, ReconciliationOut
from .services.importer import read_invoice_file
from .services.reconciliation import run_reconciliation

Base.metadata.create_all(bind=engine)
app=FastAPI(title=settings.app_name,version="0.1.0",description="TaxSync GST Reconciliation MVP API")
app.add_middleware(CORSMiddleware,allow_origins=settings.allowed_origins,allow_credentials=False,
                   allow_methods=["*"],allow_headers=["*"])

@app.get("/api/health")
def health():
    return {"status":"ok","app":settings.app_name,"version":"0.1.0","timestamp":datetime.utcnow().isoformat()}

@app.get("/api/companies",response_model=list[CompanyOut])
def list_companies(db:Session=Depends(get_db)):
    return db.query(models.Company).order_by(models.Company.name).all()

@app.post("/api/companies",response_model=CompanyOut,status_code=201)
def create_company(payload:CompanyCreate,db:Session=Depends(get_db)):
    company=models.Company(name=payload.name.strip(),legal_name=payload.legal_name,pan=payload.pan,
                            financial_year_start_month=payload.financial_year_start_month)
    for gstin in payload.gstins:
        value=gstin.strip().upper()
        if value: company.gstins.append(models.GSTIN(gstin=value))
    db.add(company); db.commit(); db.refresh(company)
    db.add(models.AuditLog(company_id=company.id,action="company_created",entity_type="company",
                           entity_id=company.id,details='{"source":"local_setup"}'))
    db.commit()
    return company

@app.get("/api/companies/{company_id}/invoices")
def list_invoices(company_id:int,source:str|None=None,db:Session=Depends(get_db)):
    query=db.query(models.Invoice).filter_by(company_id=company_id)
    if source: query=query.filter_by(source=source)
    rows=query.order_by(desc(models.Invoice.id)).limit(1000).all()
    return [{"id":x.id,"source":x.source,"supplier_gstin":x.supplier_gstin,"invoice_number":x.invoice_number,
             "invoice_date":x.invoice_date,"taxable_value":x.taxable_value,"igst":x.igst,"cgst":x.cgst,
             "sgst":x.sgst,"cess":x.cess,"invoice_value":x.invoice_value} for x in rows]

@app.post("/api/companies/{company_id}/imports")
async def import_invoices(company_id:int,source:str=Query(...,pattern="^(gstr2b|purchase_register)$"),
                          file:UploadFile=File(...),db:Session=Depends(get_db)):
    company=db.get(models.Company,company_id)
    if not company: raise HTTPException(404,"Company not found")
    content=await file.read((settings.max_upload_mb*1024*1024)+1)
    if len(content)>settings.max_upload_mb*1024*1024: raise HTTPException(413,"File exceeds upload limit")
    try: rows,rejected,total=read_invoice_file(file.filename or "upload.csv",content)
    except Exception as exc: raise HTTPException(400,f"Import failed: {exc}")
    batch=models.ImportBatch(company_id=company_id,source=source,filename=Path(file.filename or "upload").name,
        row_count=total,imported_count=len(rows),rejected_count=len(rejected),status="completed")
    db.add(batch); db.flush()
    for row in rows: db.add(models.Invoice(company_id=company_id,import_batch_id=batch.id,source=source,**row))
    db.add(models.AuditLog(company_id=company_id,action="invoice_imported",entity_type="import_batch",
        entity_id=batch.id,details=f'{{"source":"{source}","imported":{len(rows)},"rejected":{len(rejected)}}}'))
    db.commit()
    return {"batch_id":batch.id,"source":source,"filename":batch.filename,"rows_seen":total,
            "imported":len(rows),"rejected":rejected}

@app.post("/api/companies/{company_id}/reconcile",response_model=ReconciliationOut)
def reconcile(company_id:int,payload:ReconcileRequest,db:Session=Depends(get_db)):
    if not db.get(models.Company,company_id): raise HTTPException(404,"Company not found")
    a=db.query(models.Invoice).filter_by(company_id=company_id,source="gstr2b").count()
    b=db.query(models.Invoice).filter_by(company_id=company_id,source="purchase_register").count()
    if not a or not b: raise HTTPException(400,"Import both GSTR-2B and purchase-register data first.")
    return run_reconciliation(db,company_id,payload.tolerance_amount,payload.tolerance_percent,payload.date_tolerance_days)

@app.get("/api/companies/{company_id}/reconciliations",response_model=list[ReconciliationOut])
def list_reconciliations(company_id:int,db:Session=Depends(get_db)):
    return db.query(models.ReconciliationRun).filter_by(company_id=company_id).order_by(desc(models.ReconciliationRun.id)).all()

@app.get("/api/reconciliations/{run_id}/results")
def reconciliation_results(run_id:int,status:str|None=None,db:Session=Depends(get_db)):
    run=db.get(models.ReconciliationRun,run_id)
    if not run: raise HTTPException(404,"Reconciliation run not found")
    query=db.query(models.MatchResult).filter_by(run_id=run_id)
    if status: query=query.filter_by(status=status)
    results=query.order_by(models.MatchResult.id).all()
    ids={x.gstr2b_invoice_id for x in results if x.gstr2b_invoice_id}|{x.purchase_invoice_id for x in results if x.purchase_invoice_id}
    invoices={x.id:x for x in db.query(models.Invoice).filter(models.Invoice.id.in_(ids)).all()} if ids else {}
    output=[]
    for r in results:
        g,p=invoices.get(r.gstr2b_invoice_id),invoices.get(r.purchase_invoice_id)
        def brief(x):
            return {"id":x.id,"invoice_number":x.invoice_number,"supplier_gstin":x.supplier_gstin,
                    "invoice_date":x.invoice_date,"taxable_value":x.taxable_value} if x else None
        output.append({"id":r.id,"status":r.status,"category":r.category,"confidence":r.confidence,
            "explanation":r.explanation,"taxable_difference":r.taxable_difference,"tax_difference":r.tax_difference,
            "gstr2b_invoice":brief(g),"purchase_invoice":brief(p)})
    return {"run_id":run_id,"summary":{"total_gstr2b":run.total_gstr2b,"total_purchase":run.total_purchase,
        "matched":run.matched_count,"needs_review":run.review_count,"mismatches":run.mismatch_count},"results":output}
