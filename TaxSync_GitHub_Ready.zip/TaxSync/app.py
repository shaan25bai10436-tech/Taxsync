"""Root ASGI entry point. Run: uvicorn app:app --reload"""
from backend.app.main import app

__all__ = ["app"]
