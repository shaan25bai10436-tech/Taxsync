# TaxSync — Software Requirements Specification (SRS)

**Product:** TaxSync  
**Tagline:** Reconcile Smarter. Manage Better.  
**Version:** 1.0 — Requirements baseline  
**Date:** 30 October 2026  
**Status:** Approved scope baseline for initial implementation

## 1. Purpose
TaxSync is an offline-first, modular accounting, GST reconciliation and business-management platform for individual businesses, accountants/CA professionals, and small and medium businesses. The first implementation milestone is a functional GST Reconciliation MVP.

## 2. Product vision
Provide a dependable local-first platform that helps users import GST and accounting records, reconcile invoice-level data, identify discrepancies, manage review workflows and generate reports. The broader roadmap extends into accounting, finance, inventory, payroll, CRM, banking, compliance, analytics and CA-firm operations.

## 3. Stakeholders and target users
- Individual business owners and operators.
- Accountants and CA professionals managing client records.
- Small and medium businesses.
- Company administrators, finance teams and authorized reviewers.
- Future LAN/server administrators and integration providers.

## 4. Product principles
1. Offline-first core workflows.
2. User ownership and control of business data.
3. Company-level data isolation.
4. Exact matching before flexible or AI-assisted suggestions.
5. Human approval for uncertain matches and tax-sensitive changes.
6. Traceable imports, reconciliation runs and record changes.
7. No hidden uploads, mandatory cloud account or default external AI processing.
8. Government integrations only through documented and authorized access.
9. Historical tax rules and calculations must remain reproducible.
10. Deliver working, tested modules incrementally.

## 5. Scope
### 5.1 First release: Complete GST Reconciliation MVP
In scope:
- Company creation and basic GSTIN association.
- Import GSTR-2B and purchase-register data.
- CSV, XLSX, JSON and ZIP import pathways.
- Field normalization, import validation and rejected-row feedback.
- Invoice identity normalization.
- Exact matching by supplier GSTIN and normalized invoice number.
- Configurable amount and date tolerances.
- Conservative fuzzy suggestions with confidence score and explanation.
- Missing-in-register and missing-in-GSTR-2B detection.
- Taxable-value and tax difference identification.
- Reconciliation summary and invoice-level result table.
- Manual review queue.
- Reconciliation history and basic audit events.
- PDF/Excel report generation in a subsequent MVP increment after core import and matching validation.

### 5.2 Later releases
- GSTR-1 and GSTR-3B reconciliation and return preparation.
- ITC eligibility and statutory rule engine.
- Authorized GST API/GSP, e-invoice and e-way bill integration.
- Full accounting, ledgers, vouchers, invoicing and banking.
- Inventory, manufacturing, payroll, HRMS, CRM, vendors and projects.
- Fixed assets, budgeting, maintenance and business intelligence.
- CA firm client management and branch/warehouse management.
- AI assistant, local AI, OCR and forecasting.
- Advanced audit/report builder, plugin system and integrations.
- Installers, PWA/desktop launcher, LAN server, synchronization and release management.

## 6. Technology architecture
### 6.1 Confirmed stack
- Frontend: React with Vite.
- Backend: Python FastAPI.
- ORM: SQLAlchemy 2.x.
- Local database: SQLite.
- LAN/server database: PostgreSQL.
- Validation: Pydantic.
- Spreadsheet processing: openpyxl initially.
- PDF generation: ReportLab in a later reporting increment.
- Testing: pytest and HTTPX; frontend tests to be added.
- Cross-platform targets: Windows, Linux and macOS.

### 6.2 Logical architecture
React client → FastAPI application services → SQLAlchemy persistence layer → SQLite for local deployments or PostgreSQL for LAN/server deployments.

Business logic must not depend on database-specific SQL. Multiple LAN clients communicate with a central application server; they must not directly open a shared SQLite file.

### 6.3 Proposed modules
- `identity`: users, roles, sessions and permissions.
- `companies`: companies, GSTINs, branches and financial years.
- `imports`: upload, parsing, validation and import batches.
- `gst`: GST document normalization and statutory rules.
- `reconciliation`: exact, flexible and AI-assisted matching.
- `review`: mismatch assignment, approval and resolution.
- `reports`: summaries, exports and audit packages.
- `audit`: append-only event history.
- `integrations`: authorized external providers.
- `platform`: settings, backup, update and diagnostics.

## 7. Functional requirements
**FR-01 Company setup:** Authorized users can create companies with name, legal name, PAN (optional), financial-year start month and GSTINs.

**FR-02 Data import:** Accept CSV, XLSX, JSON and ZIP files containing supported invoice records; record source, filename, timestamp, row counts and rejected rows.

**FR-03 Field mapping:** Normalize supplier GSTIN, invoice number/date, taxable value, IGST, CGST, SGST, cess and invoice value aliases.

**FR-04 Import validation:** Flag rows without a usable invoice number and report row-level errors. Preserve or traceably reference source data.

**FR-05 Exact matching:** First attempt matching on normalized supplier GSTIN and invoice number.

**FR-06 Tolerance handling:** Apply configurable monetary, percentage and date tolerances; store them with each run.

**FR-07 Flexible matching:** Suggest candidates when invoice number formatting, date or amount differs within configured similarity limits.

**FR-08 AI-assisted matching:** Future AI suggestions provide confidence and explanations; never silently confirm them.

**FR-09 Discrepancy classification:** Classify matched, possible-match/review, missing in purchase register, missing in GSTR-2B, amount difference, tax difference and validation issues.

**FR-10 Summary:** Show source counts, matched count, review count and mismatch count.

**FR-11 Review workflow:** Authorized users inspect source invoices and decide whether a suggested match is valid. Future resolution actions record actor, timestamp, reason and before/after values.

**FR-12 History:** Preserve prior reconciliation runs, parameters and results.

**FR-13 Reporting:** Provide supplier-wise, month-wise, ITC and discrepancy reports, with PDF and Excel exports in a later increment.

**FR-14 Auditability:** Log company creation, imports, reconciliation runs and future approval/resolution actions.

**FR-15 Company isolation:** Company-owned records are scoped by company ID and protected by authorization checks before multi-user release.

## 8. Initial data model
- Company: name, legal name, PAN, financial-year settings.
- GSTIN: company ID, GSTIN, state code, active status.
- ImportBatch: company ID, source, filename, row counts, status and timestamp.
- Invoice: company ID, import batch, source, supplier GSTIN, invoice number/date, taxable value, tax components, invoice value and raw source reference.
- ReconciliationRun: company ID, tolerance settings, source counts and result counts.
- MatchResult: run ID, source invoice references, status, category, confidence, explanation, differences and approval state.
- AuditLog: company ID, action, entity reference, details and timestamp.

Production schema will use Alembic migrations, explicit Decimal/Numeric money types, idempotency constraints, indexes and retention policies. Floating-point money storage in the prototype is not the final financial precision design.

## 9. Non-functional requirements
- **NFR-01 Offline:** Core company, import and reconciliation workflows operate without internet after installation.
- **NFR-02 Cross-platform:** Shared application core with platform-specific packaging for Windows, Linux and macOS.
- **NFR-03 Integrity:** Production financial data uses decimal precision; imports and runs are transactional and recoverable.
- **NFR-04 Security:** Production release requires authentication, RBAC, least privilege, secure password hashing, input validation, encrypted backups, TLS for LAN, secure key management and security testing.
- **NFR-05 Privacy:** No business data transmitted externally without explicit consent and authorized integration.
- **NFR-06 Auditability:** Financial changes and review decisions are traceable; no silent overwrite/delete.
- **NFR-07 Performance:** Paginated queries and background processing for large imports; formal targets set after benchmarking.
- **NFR-08 Maintainability:** Separated backend modules, frontend features and persistence adapters; automated tests and migrations.
- **NFR-09 Recovery:** Backup, restore, integrity checks and update rollback before production.
- **NFR-10 Accessibility:** Responsive layouts, keyboard navigation and clear validation feedback.

## 10. Security and compliance constraints
- The starter is a development scaffold, not a security-certified product.
- Authentication, authorization, encryption-at-rest, key management and production audit controls are release blockers.
- GST rules must be versioned by effective date and reviewed against official notifications.
- Filing and portal connectivity require officially authorized access, provider agreements and user approval.
- OCR and AI results require human verification.
- No autonomous filing, payment, posting or alteration of financial records.
- Local GSTIN format checks are not proof of active registration.

## 11. MVP acceptance criteria
1. Create a company.
2. Import supported GSTR-2B data.
3. Import supported purchase-register data.
4. Show imported and rejected rows.
5. Run reconciliation with visible tolerances.
6. Classify identity matches separately from amount/date mismatches.
7. Mark fuzzy suggestions as requiring review.
8. Show unmatched records on either side.
9. Display identifiers, status, differences and explanation.
10. Retain reconciliation history.
11. Pass core tests on supported Python.
12. Run locally without internet after dependencies are installed.

## 12. Development roadmap
- **Phase 0 — Foundation (current):** Repository scaffold, database configuration, company setup, import parser, reconciliation service, React workspace and tests.
- **Phase 1 — Reconciliation hardening:** Decimal money precision, Alembic migrations, GST JSON adapters, duplicate handling, idempotent imports, supplier/month reports, PDF/Excel exports and review workflow.
- **Phase 2 — Identity and security:** Users, authentication, RBAC, company scoping, approvals, encrypted backup and audit hardening.
- **Phase 3 — GST expansion:** GSTR-1/3B comparisons, ITC rules, versioned statutory engine, filing preparation and authorized integrations.
- **Phase 4 — Accounting/business:** Double-entry accounting, ledgers, invoices, banking, inventory, payroll, CRM and other modules.
- **Phase 5 — Enterprise deployment:** PostgreSQL LAN mode, installers, desktop launcher, PWA, backup/restore, updates and cross-platform QA.

## 13. Risks and mitigations
| Risk | Mitigation |
|---|---|
| GST source files vary | Versioned parsers, sample fixtures, previews and schema validation |
| False-positive fuzzy matches | Conservative thresholds, explanations and human review |
| Monetary precision errors | Decimal/Numeric in production; rounding and tax tests |
| Concurrent LAN writes | Central FastAPI server with PostgreSQL |
| Data loss | Transactional imports, tested backups and restore drills |
| Regulatory changes | Effective-dated rules, official sources and human approval |
| Scope expansion | GST MVP first; later modules gated |

## 14. Assumptions and open implementation details
- MVP supports normalized invoice data files; comprehensive portal-export schema support requires representative samples.
- Real GSTR-2B and purchase-register samples are needed to validate mappings.
- Initial matching is deterministic and explainable; AI is a later layer.
- Current scaffold does not yet include authentication, production encryption, migrations or installer packaging.
- Tax/statutory behaviour requires qualified professional review.

## 15. Approval baseline
This SRS consolidates the 135-question requirements process and establishes the implementation baseline for the first GST Reconciliation MVP. Scope changes should be versioned rather than silently expanding the first release.
