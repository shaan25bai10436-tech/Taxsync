# TaxSync — GST Reconciliation MVP

**Reconcile Smarter. Manage Better.**

TaxSync is an early-stage, offline-first GST reconciliation prototype. It provides company setup, GSTR-2B and purchase-register imports, invoice matching, mismatch review and reconciliation history.

> **Important:** This repository is a development MVP, not production-ready tax software. It has no authentication or authorization yet. Do not deploy it with real company, customer, supplier, GST, or financial data. Do not use it to file returns or make tax decisions without qualified professional review.

## Technology
- Frontend: React 18 + Vite
- Backend: Python 3.11+ + FastAPI
- ORM: SQLAlchemy 2.x
- Database: SQLite locally; PostgreSQL can be configured using `DATABASE_URL`
- Imports: CSV, XLSX, JSON and basic ZIP handling

## Repository layout
```text
TaxSync/
├── app.py                  # Root FastAPI/ASGI entry point
├── requirements.txt        # Python dependencies
├── render.yaml             # Optional Render demo deployment
├── backend/
│   ├── app/                # FastAPI application and services
│   └── tests/
├── frontend/               # React + Vite application
├── samples/                # Synthetic sample CSVs
└── docs/                   # SRS documents
```

## Run locally on Windows
Install Python 3.11+ and Node.js 20+.

**Terminal 1 — backend (from the repository root):**
```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
uvicorn app:app --reload
```

**Terminal 2 — frontend:**
```powershell
cd frontend
npm install
npm run dev
```

Open the Vite URL shown in the terminal (normally `http://localhost:5173`). API docs: `http://127.0.0.1:8000/docs`.

## Run locally on macOS/Linux
**Terminal 1 — backend:**
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app:app --reload
```
**Terminal 2 — frontend:**
```bash
cd frontend
npm install
npm run dev
```

## Upload to GitHub
1. Create a new empty GitHub repository, e.g. `TaxSync`.
2. Extract this ZIP and open a terminal in the extracted `TaxSync` folder.
3. Run (replace `YOUR-USERNAME`):
```bash
git init
git add .
git commit -m "Initial TaxSync MVP"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/TaxSync.git
git push -u origin main
```
Never commit `.env`, database files, backups, API keys, or real financial data. `.gitignore` excludes local databases and secrets.

## Optional Render demo deployment
The included `render.yaml` describes a demo API service and static frontend. In Render, choose **New → Blueprint**, connect the GitHub repository, and review the services before deploying.
- Frontend API URL uses `VITE_API_BASE_URL`.
- API health check: `/api/health`.
- The Blueprint uses SQLite on a free web service. Render's local filesystem is ephemeral, so database contents can be lost on restart/redeploy. This is only for a disposable demo.
- For persistent hosted data, configure managed PostgreSQL and set `DATABASE_URL` to its connection string. Backups, access controls, migrations and security hardening are required before real use.
- This MVP has no login or tenant isolation. Do not expose real business data publicly.

## API endpoints
- `GET /api/health`
- `GET /api/companies`
- `POST /api/companies`
- `POST /api/companies/{id}/imports?source=gstr2b`
- `POST /api/companies/{id}/reconcile`
- `GET /api/companies/{id}/reconciliations`
- `GET /api/reconciliations/{run_id}/results`

## Tests
```bash
pip install -r requirements.txt
cd backend
pytest
```

## Known limitations
This is an MVP scaffold. Authentication/RBAC, tenant isolation, production encryption and key management, Alembic migrations, decimal money precision, complete GST portal schema adapters, authorized GST integrations, PDF/Excel reporting, robust duplicate-import protection, backup/recovery, installers and security testing remain to be implemented.
